from selenium.webdriver import ActionChains
from ketangpai.Common.page.login import Login
from selenium.webdriver.common.by import By
from time import sleep

class UpLoad:
    Login().register('13541781424','19931025')

    def uploadfile(self,class_name,work_name,file_path,):
         sleep(3)
         #定位班级
         Login().wait(By.XPATH,"//*[@id='viewer-container-lists']//*[@title='%s']" % class_name).click()
         sleep(3)
         Login().wait(By.XPATH,"//*[@title='%s']" % work_name).click()
         #定位作业列表
         ele=Login().wait(By.XPATH,"//*[@class='work-list']//h3")
         context=ele.text
         if context=="即将提交的文件":
              # 点击上传文件
              ac=ActionChains(Login().driver)
              ele=Login().wait(By.XPATH,"//div[text()='上传文件']")
              ac.move_to_element(ele).click(ele).perform()
              sleep(2)
              Login().upload_file(file_path)
              sleep(2)
              # Login().wait(By.XPATH,"//a[text()='提交']").click()
         else:
              #定位更新提交按钮
               ele=Login().wait(By.XPATH,"//a[text()='更新提交' and @class='new-tj1']")
               #创建一个新的动作链。
               ac=ActionChains(Login().driver)
               #将鼠标移动到更新提交按钮上点击按钮
               ac.move_to_element(ele).click().perform()
               #定位弹窗
               Login().wait(By.XPATH,"//*[@id='update-pop']//a[text()='确定']").click()
               #定位上传文件
               ele=Login().wait(By.XPATH,"//*[text()='上传文件']")
               #将鼠标移动到上传文件按钮上
               ac.move_to_element(ele).perform()
               #点击按钮
               ac.click().perform()
               sleep(2)
               #上传文件
               Login().upload_file(file_path)
               #点击提交
               sleep(2)
               Login().wait(By.XPATH,"//a[contains(@class,'new-tj2')]").click()
               e=Login().wait(By.XPATH,"//a[contains(@class,'new-tj2')]")
               #将鼠标移动到上传文件按钮上
               ac.move_to_element(e).click(e).perform()
          #点击作业留言
          Login().wait(By.XPATH,"//*[contains(@class,'work-message clearfix')]/*[@class='s2']").click()
          Login().wait(By.XPATH,"//*[@id='comment']").send_keys('哈哈哈')
          #点击保存
          Login().wait(By.XPATH,"//a[text()='保存']").click()
          sleep(2)
          Login.driver.save_screenshot('D:\ketangpai\Data\img\msg.png')
          # 点击提交
          Login().wait(By.XPATH,"//*[text()='提交']").click()
          Login.driver.back()
# #查看作业提交状态
# ele=Login().wait(By.XPATH,"//a[@title='项目实战作业']/parent::h3/parent::div/parent::div//a[@class='sc-btn']")
# context=ele.text
# print(context)
# sleep(2)
if __name__ == '__main__':
    UpLoad().uploadfile('python全栈第14期','项目实战作业','D:\pycharm\ketangpai\\run.py')