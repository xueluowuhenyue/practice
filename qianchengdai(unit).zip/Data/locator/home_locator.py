# -*- coding:utf-8 -*-
from selenium.webdriver.common.by import By
# 项目先借一个亿
bid_project=(By.XPATH,"//a[text()='抢投标']")

