# -*- coding:utf-8 -*-
from selenium.webdriver.common.by import By

#获取投资后的余额
end_money=(By.XPATH,"//*[@class='color_sub']")